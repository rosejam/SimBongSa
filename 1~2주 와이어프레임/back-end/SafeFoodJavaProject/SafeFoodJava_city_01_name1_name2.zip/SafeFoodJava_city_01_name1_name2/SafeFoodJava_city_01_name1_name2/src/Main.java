import com.ssafy.view.FoodInfoView;


public class Main {
	public static void main(String[] args) {
		new FoodInfoView();
	}
}
